﻿Public Class frmWelcome
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnWelcome_Click(sender As Object, e As EventArgs) Handles btnWelcome.Click

    End Sub
End Class
